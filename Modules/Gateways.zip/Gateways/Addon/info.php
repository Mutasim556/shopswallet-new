<?php return array(
    'software_id' => '48481246',
    'name' => 'Payment & Sms gateways',
    'is_published' => 0,
    'database_migrated' => 0,
    'purchase_code' => '',
    'username' => '',
    'class_files_updated' => 0,
    'migrations' =>
        array(
            0 =>
                array(
                    'key' => 'update_0001.sql',
                    'value' => 0,
                    'key_names' =>
                        array(
                            0 => 'instamojo',
                            1 => 'phonepe',
                            2 => 'cashfree',
                        ),
                    'settings_type' => 'payment_config',
                ),
        ),
);
