<?php return array(
    [
        'name' => 'payment_setup',
        'url' => url('/') . '/admin/payment/configuration/addon-payment-get',
        'path'=>'admin/payment/configuration/addon-payment-get'
    ],
    [
        'name' => 'sms_setup',
        'url' => url('/') . '/admin/sms/configuration/addon-sms-get',
        'path'=>'admin/sms/configuration/addon-sms-get'
    ]
);
