'use strict';
document.from1.submit();
