'use strict';
document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("pay-button").click();
});
