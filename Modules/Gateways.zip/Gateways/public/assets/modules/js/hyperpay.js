 'use strict';
  var wpwlOptions = {
        style: "card",
        locale: "en",
        paymentTarget: "_top"
    }
