'use strict';
document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("form").submit();
});
